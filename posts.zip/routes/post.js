const express = require('express');
const router = express.Router();
const passport = require('passport');
const Post = require('../models/post');

// Create a post
router.post('/', passport.authenticate('jwt', { session: false }), async (req, res) => {
    const { title, body, latitude, longitude } = req.body;

    try {
        const newPost = new Post({
            title,
            body,
            createdBy: req.user.id,
            location: {
                type: 'Point',
                coordinates: [longitude, latitude]
            }
        });

        const post = await newPost.save();
        res.json(post);
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Get all posts by the authenticated user
router.get('/', passport.authenticate('jwt', { session: false }), async (req, res) => {
    try {
        const posts = await Post.find({ createdBy: req.user.id });
        res.json(posts);
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Get a specific post
router.get('/:id', passport.authenticate('jwt', { session: false }), async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post || post.createdBy.toString() !== req.user.id) {
            return res.status(404).json({ msg: 'Post not found' });
        }
        res.json(post);
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Update a post
router.put('/:id', passport.authenticate('jwt', { session: false }), async (req, res) => {
    const { title, body, active, latitude, longitude } = req.body;

    try {
        let post = await Post.findById(req.params.id);
        if (!post || post.createdBy.toString() !== req.user.id) {
            return res.status(404).json({ msg: 'Post not found' });
        }

        post.title = title || post.title;
        post.body = body || post.body;
        post.active = active !== undefined ? active : post.active;
        post.location.coordinates = [longitude, latitude] || post.location.coordinates;

        post = await post.save();
        res.json(post);
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Delete a post
router.delete('/:id', passport.authenticate('jwt', { session: false }), async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);
        if (!post || post.createdBy.toString() !== req.user.id) {
            return res.status(404).json({ msg: 'Post not found' });
        }

        await post.remove();
        res.json({ msg: 'Post removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Retrieve posts by latitude and longitude
router.get('/location', passport.authenticate('jwt', { session: false }), async (req, res) => {
    const { latitude, longitude } = req.query;

    try {
        const posts = await Post.find({
            location: {
                $near: {
                    $geometry: {
                        type: 'Point',
                        coordinates: [longitude, latitude]
                    },
                    $maxDistance: 10000 // 10 km
                }
            }
        });
        res.json(posts);
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

// Dashboard: Get count of active and inactive posts
router.get('/dashboard/count', passport.authenticate('jwt', { session: false }), async (req, res) => {
    try {
        const activeCount = await Post.countDocuments({ createdBy: req.user.id, active: true });
        const inactiveCount = await Post.countDocuments({ createdBy: req.user.id, active: false });

        res.json({
            active: activeCount,
            inactive: inactiveCount
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).send(err.message);
    }
});

module.exports = router;
